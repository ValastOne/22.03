Create table SocialSecurityCompany
(
	id int identity primary key,
	�ountry nvarchar(100),
	city nvarchar(100),
	address text,
	INN bigint,
	ip_address nvarchar(20),
	payment_account bigint,
	bank_code bigint,
	last_computer text
);

Create table Patient
(
	id int identity primary key,
	name nvarchar(50),
	surname nvarchar(100),
	login nvarchar(50),
	password nvarchar(50),
	guid text,
	email nvarchar(100),
	social_security_company int references SocialSecurityCompany(id),
	social_security_number bigint,
	ein nvarchar(10),
	social_type nvarchar(3),
	phone nvarchar(25),
	passport_series int,
	passport_number bigint,
	birthday date
);

Create table Patient_blood_sample
(
	id int identity primary key,
	patient int references Patient(id),
	barcode bigint,
	date date
);

Create table User_Types
(
	id int identity primary key,
	name nvarchar(50),
	rights int
);

Create table Users
(
	id int identity primary key,
	name nvarchar(50),
	surname nvarchar(100),
	login nvarchar(50),
	password nvarchar(50),
	ip_address nvarchar(15),
	lastenter date,
	type int references User_Types(id),
	photo nvarchar(150)
);

Create table Service
(
	code bigint primary key,
	name nvarchar(100),
	price money
);

Create table UserServices
(
	id int identity primary key,
	[user] int references Users(id),
	service bigint references Service(code)
);

Create table Analyzers
(
	id int identity primary key,
	name nvarchar(100)
);

Create table Orders
(
	id int identity primary key,
	blood int references Patient_blood_sample(id),
	service bigint references Service(code),
	result real,
	finished datetime,
	accepted bit,
	status nvarchar(10),
	analyzer int references Analyzers(id),
	[user] int references Users(id)
);
create table History_login
(
	id int primary key identity,
	id_user int references Users(id),
	successfully bit,
	time datetime
);
