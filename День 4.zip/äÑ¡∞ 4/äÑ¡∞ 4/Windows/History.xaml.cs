﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace День_4.Windows
{
    /// <summary>
    /// Логика взаимодействия для History.xaml
    /// </summary>
    public partial class History : Window
    {
        bool first_launch=true;
        string path = "D:";
        Entities.Entities entities;
        public History(Entities.Users user)
        {
            InitializeComponent();
            //Выводим данные о пользователе
            Prof_img.Source = new BitmapImage(new Uri(path+user.photo));
            TB_FName.Text = user.surname+" "+user.name;
            // Выводим список
            entities = new Entities.Entities();
            LV_History.ItemsSource = entities.History_login.ToList();
            CB_Criteri.Items.Add("Без сортировки");
            CB_Criteri.Items.Add("По возрастанию");
            CB_Criteri.Items.Add("По убыванию");
            CB_Criteri.SelectedIndex = 0;
            first_launch = false;
        }

        private void BT_Exit_Click(object sender, RoutedEventArgs e)
        {
            Authorizate authorizate = new Authorizate();
            authorizate.Show();
            this.Close();
        }

        private void TB_Find_TextChanged(object sender, TextChangedEventArgs e)
        {

            //var list_history = entities.History_login.Where(c=>c.Users.login.Contains(TB_Find.Text));
            //LV_History.ItemsSource = list_history.ToList();

            Sort(entities.History_login.Where
                (c => c.Users.login.Contains(TB_Find.Text)).ToList());
        }

        private void CB_Criteri_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Sort(entities.History_login.ToList());
        }
        public void Sort(List<Entities.History_login> list)
        {
            if (!first_launch)
            {
                switch (CB_Criteri.SelectedIndex)
                {
                    case 1:
                        LV_History.ItemsSource = list.OrderBy(c => c.time);
                        break;
                    case 2:
                        LV_History.ItemsSource =
                            list.OrderByDescending(c => c.time);
                        break;
                }
            }
        }
    }
}
