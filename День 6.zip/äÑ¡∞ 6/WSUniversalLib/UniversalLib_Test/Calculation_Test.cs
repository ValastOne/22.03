﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using WSUniversalLib;
using System;
using System.Security.Policy;

namespace UniversalLib_Test
{
    [TestClass]
    public class Calculation_Test
    {
        WSUniversalLib.Calculation calculation;
        [TestMethod]
        public void GetQuantityForProduct_NonExistentProductType()
        {
            calculation = new WSUniversalLib.Calculation();
            var result = calculation.GetQuantityForProduct(5, 1, 10, 13, 15);
            Assert.AreEqual(-1, result);
        }

        [TestMethod]
        public void GetQuantityForProduct_NonExistentMaterialType()
        {
            calculation = new WSUniversalLib.Calculation();
            var result = calculation.GetQuantityForProduct(2, 3, 10, 13, 15);
            Assert.AreEqual(-1, result);
        }

        [TestMethod]
        public void GetQuantityForProduct_NonNegativeValue()
        {
            calculation = new WSUniversalLib.Calculation();
            var result = calculation.GetQuantityForProduct(2, 2, 10, 13, 15);
            Assert.IsTrue(result >= 0);
        }
        [TestMethod]
        public void GetQuantityForProduct_NegativeLenght()
        {
            calculation = new WSUniversalLib.Calculation();
            var result = calculation.GetQuantityForProduct(3, 1, 15, 20, -45);
            Assert.AreEqual(114148, result);
        }
        [TestMethod]
        public void GetQuantityForProduct_NegativeWidth()
        {
            calculation = new WSUniversalLib.Calculation();
            var result = calculation.GetQuantityForProduct(3, 1, 15, -20, 45);
            Assert.AreEqual(114148, result);
        }

        [TestMethod]
        public void GetQuantityForProduct_Calculation_1case()
        {
            calculation = new WSUniversalLib.Calculation();
            var result = calculation.GetQuantityForProduct(3,1,15,20,45);
            Assert.AreEqual(114148,result);
        }
        [TestMethod]
        public void GetQuantityForProduct_Calculation_2case()
        {
            calculation = new WSUniversalLib.Calculation();
            var result = calculation.GetQuantityForProduct(1, 1, 15, 20, 45);
            Assert.AreEqual(14895, result);
        }
        [TestMethod]
        public void GetQuantityForProduct_Calculation_3case()
        {
            calculation = new WSUniversalLib.Calculation();
            var result = calculation.GetQuantityForProduct(2, 1, 15, 20, 45);
            Assert.AreEqual(33852, result);
        }
        [TestMethod]
        public void GetQuantityForProduct_Calculation_4case()
        {
            calculation = new WSUniversalLib.Calculation();
            var result = calculation.GetQuantityForProduct(1, 2, 15, 20, 45);
            Assert.AreEqual(14868, result);
        }
        [TestMethod]
        public void GetQuantityForProduct_Calculation_5case()
        {
            calculation = new WSUniversalLib.Calculation();
            var result = calculation.GetQuantityForProduct(2, 2, 15, 20, 45);
            Assert.AreEqual(33791, result);
        }
        [TestMethod]
        public void GetQuantityForProduct_Calculation_6case()
        {
            calculation = new WSUniversalLib.Calculation();            
            var result = calculation.GetQuantityForProduct(3, 2, 15, 20, 45);
            Assert.AreEqual(113942, result);
        }

        
    }
}
