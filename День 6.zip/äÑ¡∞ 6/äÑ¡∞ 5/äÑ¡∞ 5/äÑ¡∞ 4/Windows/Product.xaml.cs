﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace День_4.Windows
{
    /// <summary>
    /// Логика взаимодействия для Product.xaml
    /// </summary>
    public partial class Product : Window
    {
        bool first_launch=true;
        string path = "D:\\Товар_import\\";
        Entities.Entities entities;
        public Product(Entities.User user,bool admin)
        {
            InitializeComponent();
            //Выводим данные о пользователе
            if (user != null)
            {
                TB_FName.Text = user.UserSurname + " " + user.UserName
                    + " " + user.UserPatronymic;
                
            }
            if (admin == true)
            {
                P_Admin.Visibility= Visibility.Visible;
            }
            entities = new Entities.Entities();
            foreach (var current_product in entities.Product)
            {
                if (current_product.ProductPhoto != "")
                {
                    current_product.Photo = new BitmapImage(
                        new Uri(path + current_product.ProductPhoto));
                }
                else 
                {
                    current_product.Photo = new BitmapImage(
                        new Uri(path + "picture.png"));
                }
                if (current_product.ProductQuantityInStock == 0)
                {
                    current_product.BackGround = "Gray";
                }
                else
                {
                    current_product.BackGround = "White";
                }
            }
                foreach (var manufac in entities.Manufacturer)
            {
                CB_Filter.Items.Add(manufac.title);
            }
            // Выводим список           
            Update(entities.Product.ToList());
            first_launch = false;
        }
        

        public void Update(List<Entities.Product> products)
        {
            LV_Product.ItemsSource = products;
            all.Text=entities.Product.Count().ToString();
            current_count.Text = all.Text;
        }

        private void BT_Exit_Click(object sender, RoutedEventArgs e)
        {
            Authorizate authorizate = new Authorizate();
            authorizate.Show();
            this.Close();
        }

        private void TB_Find_TextChanged(object sender, TextChangedEventArgs e)
        {
            Find();
        }

        private void CB_Criteri_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Find();
        }
        public void Sort(List<Entities.Product> list)
        {
            if (!first_launch)
            {
                switch (CB_Criteri.SelectedIndex)
                {
                    case 1:
                        LV_Product.ItemsSource = list.OrderBy
                            (c => c.ProductCost);                       
                        break;
                    case 2:
                        LV_Product.ItemsSource =
                            list.OrderByDescending(c => c.ProductCost);
                        break;
                    default:
                        LV_Product.ItemsSource = list;
                        break;
                }
                if (list.Count == 0)
                {
                    LV_Product.Visibility = Visibility.Hidden;
                }
                else
                {
                    LV_Product.Visibility = Visibility.Visible;
                }
                all.Text = entities.Product.Count().ToString();
                current_count.Text = list.Count.ToString(); 
            }
        }

        public void Find()
        {
            if (!first_launch)
            {
                List<Entities.Product> find_list = new List<Entities.Product>();
                //Осуществляем поиск по всем критериям
                find_list.AddRange(entities.Product.Where
                    (c => c.ProductName.Contains(TB_Find.Text)));
                find_list.AddRange(entities.Product.Where
                    (c => c.ProductDescription.Contains(TB_Find.Text)));
                find_list.AddRange(entities.Product.Where
                    (c => c.Manufacturer.title.Contains(TB_Find.Text)));
                find_list.AddRange(entities.Product.Where
                    (c => c.ProductCost.ToString().Contains(TB_Find.Text)));
                find_list = find_list.Distinct().ToList();
                Filter(find_list);
            }
        }
        public void Filter(List<Entities.Product> products)
        {
            if(CB_Filter.SelectedIndex!=0)
                products = products.Where
                    (c => c.Manufacturer.id == CB_Filter.SelectedIndex)
                    .ToList();
            Sort(products);
        }

        private void BT_Delete_Click(object sender, RoutedEventArgs e)
        {
            if (LV_Product.SelectedItem != null)
            {
                var selected = LV_Product.SelectedItem as Entities.Product;
                if (selected.OrderProduct.Count() != 0)
                {
                    MessageBox.Show("Есть заказ на данный продукт.\n" +
                        "Удаление не возможно.", "Ошибка!", MessageBoxButton.OK,
                        MessageBoxImage.Error);
                }
                else
                {
                    var result = MessageBox.Show(
                        "Вы уверены что хотите удалить продукт?",
                        "Подтверждение", MessageBoxButton.YesNo,
                        MessageBoxImage.Question);
                    if (result == MessageBoxResult.Yes)
                    {
                        entities.Product.Remove(selected);
                        entities.SaveChanges();
                        MessageBox.Show("Удалено", "Выполнено", MessageBoxButton.OK);
                        Find();
                    }
                }
            }
        }

        private void BT_Add_Click(object sender, RoutedEventArgs e)
        {
            Add_Edit add_Edit = new Add_Edit(null);
            add_Edit.Show();
            this.Close();
        }

        private void BT_Edit_Click(object sender, RoutedEventArgs e)
        {
            if (LV_Product.SelectedItem != null)
            {
                Add_Edit add_Edit = new Add_Edit(LV_Product.SelectedItem as Entities.Product);
                add_Edit.Show();
                this.Close();
            }
        }
    }
}
