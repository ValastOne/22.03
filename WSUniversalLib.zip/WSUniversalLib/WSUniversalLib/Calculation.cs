﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WSUniversalLib
{
    public class Calculation
    {
        //Статические переменные
        /// <summary>
        /// Коэфициент первого типа продукции
        /// </summary>
        static readonly double product_1_ratio = 1.1;

        /// <summary>
        ///Коэфициент второго типа продукции
        /// </summary>
        static readonly double product_2_ratio = 2.5;
        /// <summary>
        /// Коэфициент третьего типа продукции
        /// </summary>
        static readonly double product_3_ratio = 8.43;
        /// <summary>
        /// Коэфициент брака первого материала
        /// </summary>
        static readonly double material_1_ratio = 1.003;
        /// <summary>
        /// Коэфициент брака второго материала
        /// </summary>
        static readonly double material_2_ratio = 1.0012;
        /// <summary>
        /// Возвращает количество единиц продукции исходя из параметров
        /// </summary>
        /// <param name="productType">Тип продукции</param>
        /// <param name="materialType">Тип материала</param>
        /// <param name="count">Количество</param>
        /// <param name="width">Ширина</param>
        /// <param name="lenght">Длина</param>
        /// <returns></returns>
        public int GetQuantityForProduct(int productType, int materialType, int count, float width, float lenght)        
        {
            double product_ratio;
            double material_ratio;
            switch (productType)
            {
                case 1:
                    product_ratio = product_1_ratio;
                    break;
                case 2:
                    product_ratio = product_2_ratio;
                    break;
                case 3:
                    product_ratio = product_3_ratio;
                    break;
                default:
                    return -1;                    
            }
            switch (materialType)
            {
                case 1:
                    material_ratio = material_1_ratio;
                    break;
                case 2:
                    material_ratio = material_2_ratio;
                    break;
                default:
                    return -1;
            }
            double result = width * lenght * product_ratio * count * material_ratio;
            return (int)Math.Ceiling(result);
        }
    }
}
