﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SF2022User_NN_Lib
{
    public class Calculations
    {
        public string[] AvailablePeriods(TimeSpan[] startTimes, int[] durations,TimeSpan beginWorkingTime, TimeSpan endWorkingTime,int consultationTime)
        {            
            var workingTime = endWorkingTime - beginWorkingTime;
            var count_meets=((workingTime.Hours * 60 + workingTime.Minutes) / consultationTime) -1;
            TimeSpan start_record = beginWorkingTime;
            string[] result = new string[count_meets];
            int number_duration = 0;
            if (consultationTime <= 0)
            {
                return null;
            }
            if(beginWorkingTime>=endWorkingTime)
            {
                return null;
            }
            if (startTimes.Distinct().Count()!=startTimes.Count())
            {
                return null;
            }
            durations = durations.Where(c => c > 0).ToArray();
            for (int i = 0; i < count_meets; i++)
            {
                            
                result[i] = start_record.ToString(@"hh\:mm")
                       + "-" + start_record.Add(new TimeSpan(0,consultationTime,0)).ToString(@"hh\:mm");                
                for (int j = 0; j < startTimes.Length; j++)
                {
                    if ((startTimes[j] >= start_record)&&
                        (startTimes[j] < (start_record + new TimeSpan(0,consultationTime, 0))))
                    {
                        result[i] = "";
                        start_record = startTimes[j] + new TimeSpan(0, durations[number_duration],0);
                        number_duration++;
                        break;
                    }
                }
                if (result[i] != "")
                {
                    start_record = start_record.Add(new TimeSpan(0, consultationTime, 0));
                }
            }
            result = result.Where(c => c != "").ToArray();
            return result;
        }
    }
}
