﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SF2022User_NN_Lib;
using System;

namespace SF2022_Test
{
    [TestClass]
    public class TestSF
    {
        public TimeSpan[] New_Time()
        {
            TimeSpan[] timeSpans = new TimeSpan[5];
            timeSpans[0] = new TimeSpan(10, 0, 0);
            timeSpans[1] = new TimeSpan(11, 0, 0);
            timeSpans[2] = new TimeSpan(15, 0, 0);
            timeSpans[3] = new TimeSpan(15, 30, 0);
            timeSpans[4] = new TimeSpan(16, 50, 0);
            return timeSpans;
        }

        public int[] New_Durations()
        {
            int[] durations = new int[5];
            durations[0] = 60;
            durations[1] = 30;
            durations[2] = 10;
            durations[3] = 10;
            durations[4] = 40;
            return durations;
        }
        [TestMethod]
        public void AvailablePeriods_NegativeDuration()
        {
            Calculations calculations = new Calculations();
            TimeSpan[] timeSpans = New_Time();
            int[] durations = New_Durations();
            durations[0] = -60;
            string[] list = new string[20];
            list = calculations.AvailablePeriods(timeSpans, durations, new TimeSpan(8, 0, 0), new TimeSpan(18, 0, 0), 30);
            Assert.IsNull(list);
        }

        [TestMethod]
        public void AvailablePeriods_NegativeConsultatinTime()
        {
            Calculations calculations = new Calculations();
            TimeSpan[] timeSpans = New_Time();
            int[] durations = New_Durations();
            string[] list = new string[20];
            list = calculations.AvailablePeriods(timeSpans, durations, new TimeSpan(8, 0, 0), new TimeSpan(18, 0, 0), -30);
            Assert.IsNull(list);
        }

        [TestMethod]
        public void AvailablePeriods_TimeBeginmanyTimeend()
        {
            Calculations calculations = new Calculations();
            TimeSpan[] timeSpans = New_Time();
            int[] durations = New_Durations();
            string[] list = new string[20];
            list = calculations.AvailablePeriods(timeSpans, durations, new TimeSpan(10, 0, 0), new TimeSpan(8, 0, 0), -30);
            Assert.IsNull(list);
        }

        [TestMethod]
        public void AvailablePeriods_RepetstartTime()
        {
            Calculations calculations = new Calculations();
            TimeSpan[] timeSpans = new TimeSpan[5];
            timeSpans[0] = new TimeSpan(10, 0, 0);
            timeSpans[1] = new TimeSpan(10, 0, 0);
            timeSpans[2] = new TimeSpan(15, 0, 0);
            timeSpans[3] = new TimeSpan(15, 30, 0);
            timeSpans[4] = new TimeSpan(16, 50, 0);
            int[] durations = New_Durations();
                string[] list = new string[20];
            list = calculations.AvailablePeriods(timeSpans, durations, new TimeSpan(10, 0, 0), new TimeSpan(8, 0, 0), -30);
            Assert.IsNull(list);
        }


    }
}
