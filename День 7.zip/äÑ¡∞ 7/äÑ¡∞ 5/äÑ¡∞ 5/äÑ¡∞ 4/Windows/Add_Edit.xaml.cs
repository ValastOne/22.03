﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Mapping;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace День_4.Windows
{
    /// <summary>
    /// Логика взаимодействия для Add_Edit.xaml
    /// </summary>
    public partial class Add_Edit : Window
    {
        Entities.Entities entities;
        Entities.Product product;
        bool IsNew = true;
        public Add_Edit(Entities.Product old_product)
        {
            entities = new Entities.Entities();
            InitializeComponent();            
            foreach (var current in entities.Provider)
            {
                CB_Manuf.Items.Add(current.title);
            }
            foreach (var current in entities.Product_Category)
            {
                CB_Category.Items.Add(current.title);
            }
            if (old_product != null)
            {
                product = old_product;
                img.Text = product.ProductPhoto;
                TB_Name.Text = product.ProductName;
                TB_Description.Text = product.ProductDescription;
                CB_Manuf.SelectedValue = product.Provider;
                CB_Category.SelectedValue = product.ProductCategory;
                TB_Cost.Text = product.ProductCost.ToString();
                TB_Count.Text = product.ProductQuantityInStock.ToString();
                TB_Unit.Text = product.ProductStatus;
                IsNew = false;
                Main_Win.Title = "Редактирование продукта";
            }
        }

        private void BT_Save_Click(object sender, RoutedEventArgs e)
        {
            if ((TB_Name.Text != "") && (TB_Description.Text != "") &&
                (TB_Cost.Text != "") && (TB_Count.Text != "")
                && (TB_Unit.Text!=""))
            {
                if (IsNew)
                {
                    Entities.Product new_prod = new Entities.Product();
                    new_prod.ProductName = TB_Name.Text;
                    new_prod.ProductDescription = TB_Description.Text;
                    new_prod.Manufacturer = entities.Manufacturer.Where(c => c.title == CB_Manuf.Text).First();
                    new_prod.ProductCost = Convert.ToInt16(TB_Cost.Text);
                    new_prod.ProductQuantityInStock = Convert.ToInt16(TB_Count.Text);
                    if ((new_prod.ProductCost >= 0) && (new_prod.ProductQuantityInStock >= 0))
                    {
                        entities.Product.Add(new_prod);
                        entities.SaveChanges();
                        MessageBox.Show("Сохранение успешно выполнено", "Выполнено!");
                        return;
                    }
                    else
                    {
                        MessageBox.Show("Ошибка");
                    }
                }
                else
                {
                    product.ProductName = TB_Name.Text;
                    product.ProductDescription = TB_Description.Text;
                    product.Manufacturer = entities.Manufacturer.Where(c => c.title == CB_Manuf.Text).First();
                    product.ProductCategory = CB_Category.SelectedIndex+1.ToString();
                    product.ProductCost = Convert.ToDecimal(TB_Cost.Text);
                    product.ProductQuantityInStock = Convert.ToInt16(TB_Count.Text);
                    product.ProductStatus = TB_Unit.Text;                   
                    if ((product.ProductCost >= 0) && (product.ProductQuantityInStock >= 0))
                    {
                        entities.SaveChanges();
                        return;
                    }
                    else
                    {
                        MessageBox.Show("Ошибка");
                    }
                }
            }
            else
            {
                MessageBox.Show("Ошибка");
            }
        }

        private void BT_Exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
