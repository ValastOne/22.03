﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using День_4.Entities;

namespace День_4.Windows
{
    /// <summary>
    /// Логика взаимодействия для Authorizate.xaml
    /// </summary>
    public partial class Authorizate : Window
    {
        Entities.Entities entities;
        string password = "";
        int time=10;
        bool IsNewCaptcha=true; //Проверка что каптча показывается впервые 
        public Authorizate()
        {
            InitializeComponent();
            try
            {
                entities = new Entities.Entities();
            }
            catch(Exception ex) 
            {
                MessageBox.Show("Ошибка выполнения:\n" + ex.Message, "Ошибка!"
                    , MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        
        private void Generate_Captcha()
        {
            grd1.Visibility = Visibility.Visible;
            Capch.Children.Clear();
            String allowchar = " ";
            // Создание массива символов
            allowchar = "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z";
            allowchar += "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,y,z";
            allowchar += "1,2,3,4,5,6,7,8,9,0";
            char[] a = { ',' };
            String[] b = allowchar.Split(a);
            String ct1 = "", ct2 = "";
            string rand = " ";
            Random rd = new Random();
            // Генерация пароля CAPTCHA
            int k = rd.Next(4);
            for (int i = 0; i < k; i++)
            {
                rand = b[rd.Next(b.Length)];
                ct1 += rand;
            }
            for (int i = k; i < 6; i++)
            {
                rand = b[rd.Next(b.Length)];
                ct2 += rand;
            }
            t1.Text = ct1;
            t2.Text = ct2;
            // Генерация шрифта пароля CAPTCHA
            switch (rd.Next(0, 4))
            {
                case 0:
                    t1.FontFamily = new FontFamily("Segoe Script");
                    break;
                case 1:
                    t1.FontFamily = new FontFamily("MV Boli");
                    break;
                case 2:
                    t1.FontFamily = new FontFamily("Frank Ruehl CLM");
                    break;
                case 3:
                    t1.FontFamily = new FontFamily("Ink Free");
                    break;
                case 4:
                    t1.FontFamily = new FontFamily("Gabriola");
                    break;
            }
            switch (rd.Next(0, 4))
            {
                case 0:
                    t2.FontFamily = new FontFamily("Segoe Script");
                    break;
                case 1:
                    t2.FontFamily = new FontFamily("MV Boli");
                    break;
                case 2:
                    t2.FontFamily = new FontFamily("Frank Ruehl CLM");
                    break;
                case 3:
                    t2.FontFamily = new FontFamily("Ink Free");
                    break;
                case 4:
                    t2.FontFamily = new FontFamily("Gabriola");
                    break;
            }
            // Создание объектов, для шифровки пароля CAPTCHA
            t1.FontSize = rd.Next(20, 30);
            t2.FontSize = rd.Next(20, 30);
            Random r = new Random();
            for (int i = 0; i < 10; i++)
            {
                Ellipse el = new Ellipse();
                el.Fill = new SolidColorBrush(Color.FromRgb(200, 225, 225));
                el.Width = 5;
                el.Height = 5;
                el.Margin = new Thickness(r.Next(5, 100),
                    r.Next(5, 30), 0, 0);
                Capch.Children.Add(el);
            }

        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            Generate_Captcha();
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            Login();            
        }
        private void Guest_Click(object sender, RoutedEventArgs e)
        {
            Product product = new Product(null, false);
            product.Show();
            this.Close();
        }

        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if ((TB_Login != null) && (TB_Password != null))
            {
                if (TB_Login.Text == "Login")
                    TB_Login.Text = "";
                if(TB_Password.Text=="Password")
                    TB_Password.Text = "";
            }
        }
        private void Timer_Start()
        {
            // Создание и запуск таймера
            DispatcherTimer timer = new DispatcherTimer();
            timer.Tick += new EventHandler(timerTick);
            timer.Interval = new TimeSpan(0, 0, 1);
            time =10;
            timer.Start();
            GD_Main.IsEnabled = false;            
        }
        private void timerTick(object sender, EventArgs e)
        {
            time = time - 1;           
            if (time == 0)
            {
                MessageBox.Show("Ограничение на ввод снято," +
                    "повторите попытку!", "Внимание!"
                    , MessageBoxButton.OK, MessageBoxImage.Information);
                GD_Main.IsEnabled = true;
                Generate_Captcha();
            }

        }        
        
        public void Login()
        {
            Entities.User search = null;
            try
            {
                if (!IsNewCaptcha)
                {
                    if (tbcap.Text != t1.Text + t2.Text)
                    {
                        MessageBox.Show("Неверный код Captcha," +
                         "система заблокирована!", "Ошибка"
                         , MessageBoxButton.OK, MessageBoxImage.Error);
                        Timer_Start();
                        IsNewCaptcha = false;
                        return;
                    }
                }
                    var search_list = entities.User.Where(c => c.UserLogin == TB_Login.Text);
                    if (search_list.Count() != 0)
                    {
                        search = search_list.First();

                    if (search.UserPassword == TB_Password.Text)
                    {
                        Product window_history;
                        switch (search.UserRole)
                        {
                            case 1:
                                window_history = new Product(search,true);
                                break;
                            case 2:
                                window_history = new Product(search, false);
                                break;
                            case 3:
                                window_history = new Product(search, false);
                                break;
                            default:
                                window_history = new Product(search, false);
                                break;
                        }                        
                        window_history.Show();
                        this.Close();
                        return;
                    }
                    else
                    {
                                               MessageBox.Show("Логин или пароль введены не верно," +
                       "повторите попытку!", "Ошибка"
                       , MessageBoxButton.OK, MessageBoxImage.Error);
                        
                    }
                    }
                    MessageBox.Show("Произошла неверная попытка входа," +
                        "Теперь необходимо ввести CAPTCHA!", "Внимание!"
                        , MessageBoxButton.OK, MessageBoxImage.Information);
                    IsNewCaptcha = false;
                    Generate_Captcha();                
            }

            catch (Exception ex)
            {
                if (ex.Message == "Последовательность не содержит элементов")
                {
                    MessageBox.Show("Логин или пароль введены не верно," +
                        "повторите попытку!", "Ошибка"
                        , MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                    MessageBox.Show("Ошибка выполнения:\n" + ex.Message,
                        "Ошибка!"
                   , MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }        
    }   
}
